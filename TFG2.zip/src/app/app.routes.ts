import { Routes } from '@angular/router';
import { CatalogComponent } from './catalog/catalog.component';
import { ComparatorComponent } from './comparator/comparator.component';
import { ForumComponent } from './forum/forum.component';

export const routes: Routes = [
    { path: 'catalog', component: CatalogComponent},
    { path: 'comparator', component: ComparatorComponent},
    { path: 'forum', component: ForumComponent},
];
