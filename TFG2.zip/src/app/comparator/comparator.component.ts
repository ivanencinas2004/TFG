import { Component } from '@angular/core';

@Component({
  selector: 'app-comparator',
  standalone: true,
  imports: [],
  templateUrl: './comparator.component.html',
  styleUrl: './comparator.component.css'
})
export class ComparatorComponent {

}
