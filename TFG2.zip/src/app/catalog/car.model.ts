export interface Car {
    id: number;
    image: string;
    brand: string;
    model: string;
    year: number;
    price: number;
  }
  