import {
  InputText,
  InputTextModule
} from "./chunk-JEE4TCUD.js";
import "./chunk-ATE3Z6RW.js";
import "./chunk-IBFTYWYR.js";
import "./chunk-C6P4HLFX.js";
import "./chunk-IIXUBVVP.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
